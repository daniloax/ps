/* Testar erros:

	Léxico: Token invalido
	Sintático: Não é uma expressão válida na gramática
	Semântico: Ao relacionar uma linha com outra linha da erro
	

*/

/* IMPRIMIR O TIPO DE ERRO E QUAL A LINHA */
int g_contador_de_linhas = 1;
g_error_flag = 0;

/* ERRO LEXICO */
/* tokens invalidos;  */

{ declaracoes ausentes;
{ declaracoes repetidas;
{ pulo para rotulos invalidos; SEMANTICO
{ diretivas invalidas;
{ instrucoes invalidas;
{ diretivas ou instrucoes na secao errada
{ divisao por zero;
{ instrucoes com a quantidade de operando invalida;

{ dois rotulos na mesma linha; SINTATICO
{ rotulos repetidos; SEMANTICO 
{ secao (TEXT ou DATA) faltante;
{ secao invalida;
{ tipo de argumento invalido;
            if(op1!=NULL)
                printf("operand1: %s ", op1);
            if(op2!=NULL)
                printf("operand2: %s ", op2);

            printf("\n");
        }
        else
        {
            printf("ERRO sintatico na linha %d", lc);
        }
{ endereco de memoria nao reservado;
{ modificacao de um valor constante.

*/