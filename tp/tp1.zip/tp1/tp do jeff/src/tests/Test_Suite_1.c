#include "Test_Suite_1.h"

int check_file (FILE *input)
{
	input = fopen("/home/lsz001/workspace/linker-assembler/input_tests/moda.asm","r");
	load_parser();
    mpca_lang(MPCA_LANG_DEFAULT,
              " line        :   <label>? <directive> <comment>? | <label>?  <instruction> <comment>? | <comment>;"
              " directive   :   \"SPACE\" <number>? | \"CONST\" <number> | \"EXTERN\" | \"BEGIN\" |                                                                          ;"
              " instruction :   <inst0sz> | <inst1sz> | <inst2sz>                                                                                            ;"
              " label       :   /[a-zA-Z_][a-zA-Z0-9_]*:/                                                                                                      ;"
              " comment     :   /\;.*/                                                                                                                      ;"
              " inst0sz     :   \"STOP\" | \"END\"                                                                                                                    ;"
              " inst1sz     :   (\"ADD\"|\"SUB\"|\"MULT\"|\"INPUT\"|\"DIV\"|\"JMPN\"|\"JMPP\"|\"JMPZ\"|\"LOAD\"|\"STORE\") <soperand> | (\"JMP\"| \"PUBLIC\") <literal> | \"OUTPUT\" <expr> | \"SECTION\" (\"TEXT\"|\"DATA\")                     ;"
              " inst2sz     :   \"COPY\" <doperands>                                                                                                         ;"
              " soperand    :   <number> | <literal>                                                                                                 ;"
              " doperands   :   <operand> (',') <expr>                                                                 ;"
              " operand     :    ('+'|'-')? (<number>|<literal>)   ;"
              " number      :   ('+'|'-')?  (<hex>|<dec>)                                                                                                ;"
              " hex         :   \"0x\"/[0-9a-fA-F]/+                                                                                                               ;"
              " dec         :   /[0-9]/+                                                                                    ;"
              " literal     :   (/[_a-zA-Z0-9]/)+ ;"
              " expr        :   <operand>  (('+'|'-') <number>)?;"
              " code        :   /^/  <line> + /$/                                                                                                                 ;",
              Label, Directive, Line, Comment,  Instruction, Inst_0sz, Inst_1sz,Inst_2sz,Operand, SOperand, DOperands, Code ,Number,Dec,Hex, Literal, Expr,  NULL);

     mpc_result_t t;

    if(mpc_parse_file("", input, Code, &t )){
        printf("\nsucess !!\h");
    }else{
		mpc_err_print(t.error);
        printf("\n%s\n", mpc_err_string(t.error) );
        mpc_print(Code);
        printf("\n%d\n",t.error );
    }
    fclose(input);

    return 0;
}

int test_parse_line(char *s){
    if(parse_line(s)){
		printf("%s passed....\n", s);
    }else
		printf("%s NOT passed....\n", s);

    return 0;
}

int test_grammar()
{
	load_parser();

    mpc_result_t r;

    int lim=0;

    char* s[100];
    s[lim++] = "Y: ADD X1 ;COMMENT";
    s[lim++] = "ADD 10";
    s[lim++] = "ADD 0";
    s[lim++] = "ADD -1";
    s[lim++] = "ADD 0x14ef";
    s[lim++] = "SUB NUM1 ; DFD FA sfd";
    s[lim++] = "SUB 12";
    s[lim++] = "SUB -1";
    s[lim++] = "SUB -0 ; isto eh um comentario";
    s[lim++] = "ROT: SUB 99";
    s[lim++] = "SUB X ;COMMENT";
    s[lim++] = "MULT -10";
    s[lim++] = "MULT ONE1";
    s[lim++] = "MULT 2";
    s[lim++] = "ROT1: MULT XY ;;;; DFSDF";
    s[lim++] = "DIV 2 ;COMMENT";
    s[lim++] = "ROT: ADD S";
    s[lim++] = "ADD 0";
    s[lim++] = "ADD -1";
    s[lim++] = "ADD 99";
    s[lim++] = ";COMMENT 001 +FSFDaf";
    s[lim++] = "SECTION TEXT";
    s[lim++] = "ROT: INPUT N1";
    s[lim++] = "COPY N1, N4 ; comentario qualquer";
    s[lim++] = "COPY N2, N3";
     s[lim++] = "ADD 0";
    s[lim++] = "COPY N3, N3 + 1";
    s[lim++] = "OUTPUT N3 + 1";
     s[lim++] = "STOP";
    s[lim++] = "MOD_A: BEGIN";
    s[lim++] = "R: EXTERN";
     s[lim++] = "N2: CONST -0x10";
    s[lim++] = "MOD_B: EXTERN";
    s[lim++] = "N4: SPACE";
    s[lim++] = "PUBLIC B";
    s[lim++] = "COPY N2, N3";
     s[lim++] = "JMP MOD_B";
    s[lim++] = "COPY N3, N3 + 1";
    s[lim++] = "L1: OUTPUT R+1";
     s[lim++] = "STOP";
    s[lim++] = "SECTION DATA";
    s[lim++] = "N1: SPACE";
     s[lim++] = "N2: CONST -0x10";
    s[lim++] = "N3: SPACE 2";
    s[lim++] = "END; enf of code";

    int i;
    for (i=0; i<lim; i++)
    {

        char* s_in = s[i];
        test_parse_line(s_in);
        /*if (mpc_parse("input", s_in, Code, &r))
        {
            printf("%s succeded!\n", s_in);
            mpc_ast_delete(r.output);
        }
        else
        {   printf("%s  ", s_in);
            mpc_err_print(r.error);
            mpc_err_delete(r.error);
            getchar();
        } */
    }

    return 0;
}

void test_split_line(){
    int lim=0;
    char* s[100];
    s[lim++] = "Y: ADD X1 ;COMMENT";
    s[lim++] = "ADD 10";
    s[lim++] = "ADD 0";
    s[lim++] = "ADD -1";
    s[lim++] = "ADD 0x14ef";
    s[lim++] = "SUB NUM1 ; DFD FA sfd";
    s[lim++] = "SUB 12";
    s[lim++] = "SUB -1";
    s[lim++] = "SUB -0 ; isto eh um comentario";
    s[lim++] = "ROT: SUB 99";
    s[lim++] = "SUB X ;COMMENT";
    s[lim++] = "MULT -10";
    s[lim++] = "MULT ONE1";
    s[lim++] = "MULT 2";
    s[lim++] = "ROT1: MULT XY ;;;; DFSDF";
    s[lim++] = "DIV 2 ;COMMENT";
    s[lim++] = "ROT: ADD S";
    s[lim++] = "ADD 0";
    s[lim++] = "ADD -1";
    s[lim++] = "ADD 99";
    s[lim++] = ";COMMENT 001 +FSFDaf";
    s[lim++] = "SECTION TEXT";
    s[lim++] = "ROT: INPUT N1";
    s[lim++] = "COPY N1, N4 ; comentario qualquer";
    s[lim++] = "COPY N2, N3";
	s[lim++] = "ADD 0";
    s[lim++] = "COPY N3, N3 + 1";
    s[lim++] = "OUTPUT N3 + 1";
    s[lim++] = "STOP";
    s[lim++] = "MOD_A: BEGIN";
    s[lim++] = "R: EXTERN";
     s[lim++] = "N2: CONST -0x10";
     s[lim++] = "MOD_B: EXTERN";
    s[lim++] = "N4: SPACE";
    s[lim++] = "PUBLIC B";
    s[lim++] = "COPY N2, N3";
     s[lim++] = "JMP MOD_B";
    s[lim++] = "COPY N3, N3 + 1";
    s[lim++] = "L1: OUTPUT R+1";
     s[lim++] = "STOP";
    s[lim++] = "SECTION DATA";
    s[lim++] = "N1: SPACE";
     s[lim++] = "N2: CONST -0x10";
    s[lim++] = "N3: SPACE 2";
    s[lim++] = "END; enf of code";

     int i;
    for (i=0; i<lim; i++)
    {
        char* s_in = s[i];
        line_v *v;
        split_line(s_in, &v);
        printf("%s\nlabel: %s opcode: %s op1: %s op2: %s\n\n", s_in, v->label, v->opcode, v->operand1, v->operand2);

    }

}


void test_split_line_s(){

        char* s_in = "COPY N3, N3 + 1";

        line_v *v;

        split_line(s_in, &v);

        printf("%s\nlabel: %s opcode: %s op1: %s op2: %s\n", s_in, v->label, v->opcode, v->operand1, v->operand2);

        return;
}
