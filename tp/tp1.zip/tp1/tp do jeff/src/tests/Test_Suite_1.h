#ifndef TEST_SUITE_1_H_INCLUDED
#define TEST_SUITE_1_H_INCLUDED

#include "../assembler/parser.h"


int check_file (FILE *input);
int test_grammar();

//test functions
int test_parse_line(char *);

void test_split_line();
void test_split_line_s();

#endif // TEST_SUITE_1_H_INCLUDED
