#include "assembler.h"

/*
*
* Inicializa a tabela de instrucoes.
* Que foi implementada como uma lista encandeada simples.
*/
void load_assembler()
{

    add_element(&instruction_list, "ADD", 1,2);
    add_element(&instruction_list, "SUB", 2,2);
    add_element(&instruction_list, "MULT", 3,2);
    add_element(&instruction_list, "MUL", 3,2);
    add_element(&instruction_list, "DIV", 4,2);
    add_element(&instruction_list, "JMP", 5,2);
    add_element(&instruction_list, "JMPN", 6,2);
    add_element(&instruction_list, "JMPP", 7,2);
    add_element(&instruction_list, "JMPZ", 8,2);
    add_element(&instruction_list, "COPY", 9,3);
    add_element(&instruction_list, "LOAD", 10,2);
    add_element(&instruction_list, "STORE", 11,2);
    add_element(&instruction_list, "INPUT", 12,2);
    add_element(&instruction_list, "OUTPUT", 13,2);
    add_element(&instruction_list, "STOP", 14,1);
    add_element(&instruction_list, "NOP", 15,1);

    add_element(&directive_list, "SECTION", 99,0);
    add_element(&directive_list, "SPACE", 99,1);
    add_element(&directive_list, "CONST", 99,1);
    add_element(&directive_list, "PUBLIC", 99,0);
    add_element(&directive_list, "EXTERN", 99,0);
    add_element(&directive_list, "BEGIN", 99,0);
    add_element(&directive_list, "END", 99,0);

    ts=NULL;
    ts1=NULL;
    cl=NULL;
}

//roda a primeira e segunda passagem do algoritmo de montagem.
// gerando o arquivo .o de saida
void run_assembler()
{
    pc=0;
    lc=0;

    if(infile==NULL)
    {
        //printf();
        launch_error("ERROR while loading assembler...");
    }

    char *line = NULL;
    size_t len = 0;
    ssize_t read;
    printf("Iniciando primeira passagem ...");
    int foundend=0;
    while ((read = getline(&line, &len, infile)) != -1)
    {
        lc++;
        if(line[0]== '\n' && !foundend)
            continue;
        int has_label=0;
        if(parse_line(line))
        {

            char* label=NULL;
            char* op=NULL;
            char* op1=NULL;
            char* op2=NULL;

            if(strchr(line, ':')) has_label=1;

            char *pch;

            pch = strtok (line," ,:\t");
            if(has_label)
            {
                label=pch;
            }
            else
            {
                op = pch;
            }

            while (pch != NULL)
            {
                pch = strtok (NULL, " ,:\t");
                if(pch==NULL) continue;
                trim_tk(pch);

                if(has_label)
                {
                    op=pch;
                    has_label=0;
                    add_symbol_list(&ts, label, pc);
                }
                else
                {
                    //printf("operand: %s ", pch);
                    if(op1==NULL)
                        op1=pch;
                    else if(op2==NULL) op2=pch;
                }
            }
            //printf("hooray");
            //printf("\n");
            printf("%d - ", lc);

            if(label!=NULL)
            {
                printf("label: %s ", label);

            }
            if(op!=NULL)
            {
                printf("operation: %s ", op);

                if(has_inst(op))
                {
                    //printf("hahaah");
                    pc = pc + get_inst_size(op);
                    //printf("bobobob");
                }
                else if(has_dir(op))
                {
                    pc = pc + get_dir_size(op);
                }
                else {}
                //launch_error("%d: ERRO! Operacao nao identificada na linha %s ", lc, op);
            }
            if(op1!=NULL)
                printf("operand1: %s ", op1);
            if(op2!=NULL)
                printf("operand2: %s ", op2);

            printf("\n");
        }
        else
        {
            printf("ERRO sintatico na linha %d", lc);
        }
    }

    print_symbol_list();

    printf("Iniciando segunda passagem....\n");

    if(infile!=NULL)
        rewind(infile);
    else
        launch_error("ERRO! Na segunda passagem");

    line = NULL;
    len = 0;
    read=0;
    lc=0;
    pc=0;
    int hstop=0;
    while ((read = getline(&line, &len, infile)) != -1)
    {

        lc++;
        if(line[0]== '\n' || line[0]==';')
            continue;
        int has_label=0;
        if(parse_line(line))
        {

            char* label=NULL;
            char* op=NULL;
            char* op1=NULL;
            char* op2=NULL;

            if(strchr(line, ':')) has_label=1;

            char *pch;

            pch = strtok (line," ,:\t");
            if(has_label)
            {
                label=pch;
            }
            else
            {
                op = pch;
            }

            while (pch != NULL)
            {
                pch = strtok (NULL, " ,:\t");
                if(pch==NULL) continue;
                trim_tk(pch);

                if(has_label)
                {
                    op=pch;
                    has_label=0;
                    add_symbol_list(&ts1, label, pc);
                }
                else
                {
                    //printf("operand: %s ", pch);
                    if(op1==NULL)
                        op1=pch;
                    else if(op2==NULL) op2=pch;
                }
            }

            printf("%d - ", lc);

            if(label!=NULL)
            {
                printf("label: (%s %d) ", label, search_code_symbol_list(label));

            }
            if(op!=NULL)
            {
                if(op[0]=='S' && op[3]=='P')   //Gambiarra para reconhecer 'STOP'
                {
                    hstop=1;
                    printf("operation: %s %d  ", "STOP", 14);
                        add_cl(&cl, 14);

                }
                else
                {
                    printf("operation: %s %d  ", op, search_code_inst_list(op));

                    if(has_inst(op))
                    {
                        pc = pc + get_inst_size(op);

                    }
                    else if(has_dir(op))
                    {

                        pc = pc + get_dir_size(op);
                    }
                    else {}
                    //launch_error("%d: ERRO! Operacao nao identificada na linha %s ", lc, op);
                }
            }
            if(op1!=NULL)
            {

                printf("operand1: %s %d ", op1, get_op_value(op1));
            }
            if(op2!=NULL)
                printf("operand2: %s %d ", op2, get_op_value(op2));

            if(op!=NULL){
                int cd=search_code_inst_list(op);
                if(cd>=0 && !hstop){
                    printf("Binary |%.2d| ",cd );
                    add_cl(&cl, cd);
                }else{
                   if(strcmp(op, "SPACE")==0){
                      add_cl(&cl, 0);
                   }else if(strcmp(op, "CONST")==0){
                      if(op1!=NULL){
                        add_cl(&cl, (int) strtol(op1, (char **)NULL, 10) );
                      }
                   }
                }
            }
            if(op1!=NULL)
            {
                //if(strcmp(op, "STOP")==0) printf("14");
                printf(" %.2d ", get_op_value(op1)+1 );
                add_cl(&cl, get_op_value(op1)+1 );
            }
            if(op2!=NULL){
                printf("%.2d", get_op_value(op2)+1);
                add_cl(&cl, get_op_value(op2)+1 );
            }

            printf("\n");
        }
        else
        {
            printf("ERRO sintatico na linha %d", lc);
        }
    }
    print_symbol_list();
    print_cl_v(cl);

    print_cl_f(cl);
    printf("\nArquivo gravado com sucesso!");
}

//adiciona numero inteiro para ser impresso ao final
//no output padrao (video) ou um arquivo
void add_cl(dd **head, int n){

    dd* ne = (dd *)malloc(sizeof(dd));
    ne->nb = n;
    ne->next=NULL;

    if(*head==NULL){
        *head = ne;
        return;
    }
        dd* it;
        it=*head;
        while(it->next!=NULL) {
            it=it->next;
        }
        it->next=ne;
    return;
}

void print_cl_v(dd *start){
    dd* it;
    for(it=start;it!=NULL;it=it->next)
        printf("%.2d ", it->nb);
}

void print_cl_f(dd *start){
    if(outfile==NULL){
        printf("Arquivo de saida nao encontrado!\n");
        return;
    }

    dd* it;
    for(it=start;it!=NULL;it=it->next)
        fprintf(outfile, "%.2d ", it->nb);
}

int get_op_value(char *op)
{

    int ret=-1;
    if(strchr(op, '+'))
    {
        //fazer calculo matematico com o operando
    }
    else
    {
        ret= search_code_symbol_list(op);
    }
    if(ret>0)
        return ret;
    else
        return -1;
}

/*Retorna o valor numerico do opcode da instrucao (ou da directiva)
  de acordo com a string que identifica a operacao.
*/
int getopcoden(char *inst)
{

    if(strcmp("ADD", inst)==0)
    {
        return I_ADD;
    }
    else if(strcmp("SUB", inst)==0)
        return I_SUB;
    else if(strcmp("MUL", inst)==0)
        return I_MULT;
    else if(strcmp("MULT", inst)==0)
        return I_MULT;
    else if(strcmp("DIV", inst)==0)
        return I_DIV;
    else if(strcmp("JMP", inst)==0)
        return I_JMP;
    else if(strcmp("JMPN", inst)==0)
        return I_JMPN;
    else if(strcmp("JMPP", inst)==0)
        return I_JMPP;
    else if(strcmp("JMPZ", inst)==0)
        return I_JMPZ;
    else if(strcmp("COPY", inst)==0)
        return I_COPY;
    else if(strcmp("LOAD", inst)==0)
        return I_LOAD;
    else if(strcmp("STORE", inst)==0)
        return I_STORE;
    else if(strcmp("INPUT", inst)==0)
        return I_INPUT;
    else if(strcmp("OUTPUT", inst)==0)
        return I_OUTPUT;
    else if(strcmp("STORE", inst)==0)
        return I_STORE;
    else if(strcmp("SECTION", inst)==0)
        return D_SECTION;
    else if(strcmp("SPACE", inst)==0)
        return D_SPACE;
    else if(strcmp("CONST", inst)==0)
        return D_CONST;
    else if(strcmp("PUBLIC", inst)==0)
        return D_PUBLIC;
    else if(strcmp("EXTERN", inst)==0)
        return D_EXTERN;
    else if(strcmp("BEGIN", inst)==0)
        return D_BEGIN;
    else if(strcmp("END", inst)==0)
        return D_END;

    return -1;
}

/*
   Encontra o opcode numerico de acordo com
   a string que indica a operacao

*/
int search_code_inst_list(char *inst)
{
    return getopcoden(inst);
    //printf("FF |%s| %d FF ", inst, getopcoden(inst));
    /*op_node *it;

    int opcode=-1;
    for(it=instruction_list;it!=NULL;it=it->next){
        if(strcmp(it->mnemonic, inst)){
            opcode= it->code_dec;
            //printf("inst %s found ", inst);
        }
    }
    // printf("with opcode %d ", opcode);

    if(opcode>0)
        return opcode;
    else
        return -1; */
}

/*Encontra o valor de posicao de memoria na lista de simbolos
  construida na 1a passagem.
*/
int search_code_symbol_list(char *label)
{
    symbol* it;

    if(ts==NULL)
        launch_error("ERRO ao executar segunda passagem!");

    int has_s=0;
    int pos_c=-1;
    for(it=ts; it!=NULL; it=it->next)
    {
        if(strcmp(it->symbol, label)==0)
        {
            has_s=1;
            pos_c=it->pos_counter;
        }
    }
    if(has_s)
        return pos_c;
    else
        return -1;
}

/* Verifica se a instrucao encontrada existe na tabela de instrucoes.*/
int has_inst(char *inst)
{
    op_node* it;
    for(it=instruction_list; it!= NULL; it=it->next)
    {
        if(strcmp(inst, it->mnemonic )==0)
        {
            return 1;
        }
    }
    return 0;
}

int has_dir(char *dir)
{
    op_node* it;
    for(it=directive_list; it!=NULL; it=it->next)
    {
        if(strcmp(dir, it->mnemonic)==0)
            return 1;
    }
    return 0;
}

int get_inst_size(char *s)
{
    op_node *it;

    for(it=instruction_list; it!= NULL; it=it->next)
    {
        if(strcmp(s, it->mnemonic)==0)
        {
            return it->op_size;
        }
    }
    return ~0;
}

int get_dir_size(char *s)
{
    if(strcmp("SECTION", s)==0)
        return 0;
    else if(strcmp("SPACE", s)==0)
        return 1;
    else if(strcmp("CONST", s)==0)
        return 1;
    else if(strcmp("PUBLIC", s)==0)
        return 0;
    else if(strcmp("EXTERN", s)==0)
        return 0;
    else if(strcmp("BEGIN", s)==0)
        return 0;
    else if(strcmp("END", s)==0)
        return 0;
}

void add_symbol_list(symbol **head, char *label, int pos_counter)
{

    symbol* s1 = (symbol *) malloc(sizeof(symbol));
    strncpy(s1->symbol, label, sizeof(s1->symbol));
    s1->pos_counter = pos_counter;
    s1->next = NULL;

    if(*head==NULL)
    {
        *head = s1;
        return;
    }


    symbol *it;
    it=*head;

    while(it->next!=NULL)
    {
        it=it->next;
    }
    it->next = s1;

    return;
}

void print_symbol_list()
{
    symbol *it;
    it=ts;
    while(it!=NULL)
    {
        printf("%s %d ",it->symbol, it->pos_counter );
        it=it->next;
    }

    printf("\n");
}

void trim_tk(char *s)
{
    if(s==NULL) return;

    int l=strlen(s);
    l--;
    if(s[l]=='\n') s[l]='\0';


    while(s[0] =='\t' ) s++;
    while(s[0]==' ' ) s++;

}

op_node* search_element_by_opcode(op_node **start, int opcode)
{
    op_node *it;
    for(it=*start; it!=NULL; it=it->next)
    {
        if (it->code_dec == opcode)
            return it;
    }
    return NULL;
}

void add_element(op_node **head, char *mnemonic, int code_dec, int size)
{
    op_node* v = (op_node *)malloc(sizeof(op_node));
    v->code_dec = code_dec;
    v->op_size = size;
    strcpy(v->mnemonic, mnemonic);
    v->next=NULL;

    if(*head == NULL)
    {
        *head = v;
        return;
    }
    op_node *it;
    it = *head;
    while(it->next!=NULL) it=it->next;

    it->next=v;

    return;
}

void print_list(op_node **start)
{
    op_node *it;

    for(it=*start; it!= NULL; it=it->next)
    {
        printf("%s %d %d \n", it->mnemonic, it->code_dec, it->op_size);
    }
    NL;
}

void start_op_list(op_node **start)
{
    *start= NULL;
}

/* Read up to (and including) a TERMINATOR from STREAM into *LINEPTR
   + OFFSET (and null-terminate it). *LINEPTR is a pointer returned from
   malloc (or NULL), pointing to *N characters of space.  It is realloc'd
   as necessary.  Return the number of characters read (not including the
   null terminator), or -1 on error or EOF.  */

int getstr (char ** lineptr, size_t *n, FILE * stream, char terminator, int offset)
{
    int nchars_avail;             /* Allocated but unused chars in *LINEPTR.  */
    char *read_pos;               /* Where we're reading into *LINEPTR. */
    int ret;

    if (!lineptr || !n || !stream)
        return -1;

    if (!*lineptr)
    {
        *n = 64;
        *lineptr = (char *) malloc (*n);
        if (!*lineptr)
            return -1;
    }

    nchars_avail = *n - offset;
    read_pos = *lineptr + offset;

    for (;;)
    {
        register int c = getc (stream);

        /* We always want at least one char left in the buffer, since we
           always (unless we get an error while reading the first char)
           NUL-terminate the line buffer.  */

        assert(*n - nchars_avail == read_pos - *lineptr);
        if (nchars_avail < 1)
        {
            if (*n > 64)
                *n *= 2;
            else
                *n += 64;

            nchars_avail = *n + *lineptr - read_pos;
            *lineptr = (char *) realloc (*lineptr, *n);
            if (!*lineptr)
                return -1;
            read_pos = *n - nchars_avail + *lineptr;
            assert(*n - nchars_avail == read_pos - *lineptr);
        }

        if (c == EOF || ferror (stream))
        {
            /* Return partial line, if any.  */
            if (read_pos == *lineptr)
                return -1;
            else
                break;
        }

        *read_pos++ = c;
        nchars_avail--;

        if (c == terminator)
            /* Return the line.  */
            break;
    }

    /* Done - NUL terminate and return the number of chars read.  */
    *read_pos = '\0';

    ret = read_pos - (*lineptr + offset);
    return ret;
}

ssize_t getline(char **lineptr, size_t *n, FILE *stream)
{
    return getstr (lineptr, n, stream, '\n', 0);
}
