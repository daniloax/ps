#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED

#include <string.h>

#include "mpc.h"
#define TRUE 1
#define FALSE 0

typedef struct _line_v  {
   int line_num;
   char label[100];
   int has_label;
   char opcode[10];
   char operand1[50];
   int has_op2;
   char operand2[50];
} line_v;
//typedef struct _line_of_code line_v;
/*
   After the source code line is
   parsed and accepted, then it shall
   be splitted into the label, opcode,
   operand1, operand2 and comment. Such
   division is not applied to all lines of code
    (e.g. comments and labels is not mandatory for
	every line in the code). For that case, a NULL
	value will be attributed to this structure.
*/

//Input file to be checked by the parser
FILE *infile;

mpc_parser_t *Label;
mpc_parser_t *Line;
mpc_parser_t *Instruction;
mpc_parser_t *Comment;
mpc_parser_t *Inst_0sz;
mpc_parser_t *Inst_1sz;
mpc_parser_t *Inst_2sz;
mpc_parser_t *Operand;
//mpc_parser_t *Operation   = mpc_new("operation");
mpc_parser_t *SOperand;
mpc_parser_t *DOperands;
mpc_parser_t *Directive;
mpc_parser_t *Expr;
mpc_parser_t *Number;
mpc_parser_t *Dec;
mpc_parser_t *Hex;
mpc_parser_t *Literal;
mpc_parser_t *Code;
//int parse_file(FILE *);

/**
* Checks if the line read can be generated
* by the grammar defined for the hypothetical
* language created
**/
int parse_line(char *line);

/**
* Just erase the memory space previously occupied by the parser.
**/
void close_parser();

/**
* Splits the line already checked by the parser into the values
* held into LINE_V structure.
**/
void split_line(char *, line_v **);

char* get_line_file(FILE *, int);

#endif // PARSER_H_INCLUDED
