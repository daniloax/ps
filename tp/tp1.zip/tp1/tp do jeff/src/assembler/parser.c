#include "parser.h"

/*
   Fun��o que inicializa o parser automatico.
*/
void load_parser()
{
    Label       = mpc_new("label");
    Line        = mpc_new("line");
    Instruction = mpc_new("instruction");
    Comment     = mpc_new("comment");
    Inst_0sz    = mpc_new("inst0sz");
    Inst_1sz    = mpc_new("inst1sz");
    Inst_2sz    = mpc_new("inst2sz");
    Operand     = mpc_new("operand");
    //mpc_parser_t *Operation   = mpc_new("operation");
    SOperand    = mpc_new("soperand");
    DOperands   = mpc_new("doperands");
    Directive   = mpc_new("directive");
    Expr        = mpc_new("expr");
    Number      = mpc_new("number");
    Dec         = mpc_new("dec");
    Hex         = mpc_new("hex");
    Literal     = mpc_new("literal");
    Code        = mpc_new("code");
    /**
    * Defini��o de uma Gramatica Livre de Contexto
    * para reconhecimento dos tokens da linguagem.
    * Este recurso auxilia na fase de pre-processamento do codigo.
    */
    mpca_lang(MPCA_LANG_DEFAULT,
              " line        :     <label>? <directive> <comment>? | <label>?  <instruction> <comment>? | <comment>;"
              " directive   :   \"SPACE\" <number>? | \"CONST\" <number> | \"EXTERN\" | \"BEGIN\" |                                                                          ;"
              " instruction :   <inst0sz> | <inst1sz> | <inst2sz>                                                                                            ;"
              " label       :   /[a-zA-Z_][a-zA-Z0-9_]*:/                                                                                                      ;"
              " comment     :   /\;.*/                                                                                                                      ;"
              " inst0sz     :   \"STOP\" | \"END\"                                                                                                                    ;"
              " inst1sz     :   (\"ADD\"|\"SUB\"|\"MULT\"|\"MUL\"|\"INPUT\"|\"DIV\"|\"JMPN\"|\"JMPP\"|\"JMPZ\"|\"LOAD\"|\"STORE\"|\"JMP\"| \"PUBLIC\" | \"OUTPUT\")  <soperand> | \"SECTION\" (\"TEXT\"|\"DATA\")                     ;"
              " inst2sz     :   \"COPY\" <doperands>                                                                                                         ;"
              " soperand    :   <expr> | <number> | <literal>                                                                                               ;"
              " doperands   :   <operand> (',') <expr>                                                                 ;"
              " operand     :    ('+'|'-')? (<number>|<literal>)   ;"
              " number      :   ('+'|'-')?  (<hex>|<dec>)                                                                                                ;"
              " hex         :   \"0x\"/[0-9a-fA-F]/+                                                                                                               ;"
              " dec         :   /[0-9]/+                                                                                    ;"
              " literal     :   (/[_a-zA-Z0-9]/)+ ;"
              " expr        :   <operand>  (('+'|'-') <number>)?;"
              " code        :   /^/ <line> /$/                               ;",
              Label, Directive, Line, Comment,  Instruction, Inst_0sz, Inst_1sz,Inst_2sz,Operand, SOperand, DOperands, Code ,Number,Dec,Hex, Literal, Expr,  NULL);
}

/*encerra o parser automatico*/
void close_parser()
{

    mpc_cleanup(18, Label, Directive, Line, Comment,  Instruction, Inst_0sz, Inst_1sz,Inst_2sz,Operand, SOperand, DOperands, Code ,Number,Dec,Hex, Literal, Expr);
}

/*
* Recebe uma linha do codigo e faz o parsing automatico.
* E retorna uma variavel inteira que simula um booleano.
* TRUE (1) se fizer parte da linguagem assembly hipotetica.
* FALSE (0) caso contrario.
*
*/
int parse_line(char *line)
{
    char *DEFAULT_FILE_NAME="";
    mpc_result_t t;

    if(mpc_parse(DEFAULT_FILE_NAME, line, Code, &t ))
    {
        return TRUE;
    }
    else
    {
        mpc_err_print(t.error);
    }
    return FALSE;
}


void split_line(char *line, line_v **buff)
{
	if (line[0] == ';') return;

    *buff = (line_v*)malloc(sizeof(line_v));
    char *c;

    if( (c=strchr(line, ':'))!= NULL)
    {
        char label[100];
        char* pt=line;
        int i=0;
        while(pt!=c)
        {
            label[i++]=*pt;
            pt++;
        }
        label[i]='\0';
        strcpy((*buff)->label,label);

        c++;
        (*buff)->has_label=1;
    }
    else
    {
        c = line;
        (*buff)->has_label=0;
        (*buff)->label[0]='\0';
    }

    while(*c==' ') c++;

    char opcode[5];
    int i=0;
    while(*c!=' ')
    {
        opcode[i++]=*c;
        c++;
    }

    opcode[i]='\0';


    strcpy((*buff)->opcode, opcode);

    while(*c==' ') c++;

    char op1[50];
    char op2[50];
    int hasop2=0;
    i=0;
    while(*c!='\0' && *c!=';')
    {
        op1[i++] = *c;
        c++;

        if(*c==',')
        {
        	op1[i]='\0';
            hasop2=1;
            c++;
            int j=0;
            while (*c==' ') c++;

            while(*c!= ';' && *c!= '\0')
            {
                op2[j++] = *c;
                c++;
            }
            op2[j]='\0';
        }
    }
    op1[i]='\0';

    strcpy((*buff)->operand1, op1);
    if (hasop2)
    {
        strcpy((*buff)->operand2, op2);
    }
    else
    {
        (*buff)->operand2[0]='\0';
    }
    return;
}
