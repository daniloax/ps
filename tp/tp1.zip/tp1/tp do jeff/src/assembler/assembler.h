#ifndef ASSEMBLER_H_INCLUDED
#define ASSEMBLER_H_INCLUDED

#include "mpc.h"
#include "parser.h"
#include <sys/types.h>
#include <assert.h>
#include <stdlib.h>

#define NL printf("\n")

#define I_ADD 1
#define I_SUB 2
#define I_MULT 3
#define I_DIV 4
#define I_JMP 5
#define I_JMPN 6
#define I_JMPP 7
#define I_JMPZ 8
#define I_COPY 9
#define I_LOAD 10
#define I_STORE 11
#define I_INPUT 12
#define I_OUTPUT 13
#define I_STOP 14

#define D_SECTION 90
#define D_SPACE 91
#define D_CONST 92
#define D_PUBLIC 93
#define D_EXTERN 94
#define D_BEGIN 95
#define D_END   96

FILE *outfile;

int pc; // contador de posi��es
int lc; // contador de linhas


/**
* Estrutura que ira agregar o mnemonico literal
* da instrucao. O opcode decimal, e o tamanho da instrucao
* lida. Todas as informacoes sao extraidas diretamente do
* codigo fonte e armazenados em uma lista encandeada simples.
*/
typedef struct op{
  char mnemonic[10];
  int code_dec;
  int op_size;
  struct op *next;
} op_node;

op_node *instruction_list; //tabela da instrucoes
op_node *directive_list;   //tabela de directivas.


/**
  Estrutura que armazenara informacoes na lista de simbolos
  gerada na 1a passagem. Lista encandeada simples.
*/
typedef struct symbol{
    char symbol[100];
    int pos_counter;
    struct symbol *next;
} symbol;

symbol* ts; //simbolos gerados na 1a passagem.
symbol* ts1;


typedef struct dcode{
   int opcode;
   int op1;
   int op2;
   struct code *next;
}dcode;

typedef struct dd{
   int nb;
   struct dd *next;
}dd;

dd* cl;


void print_cl_v(dd *start);
void add_cl(dd **head, int n);
void start_op_list(op_node **);
void print_list(op_node **start);
void add_element(op_node **start, char *mnemonic, int code_dec, int size);
void load_assembler();
op_node* search_element_by_opcode(op_node **, int);
void run_assembler();
void print_symbol_list();

int get_op_value(char *);

//test
int check_file (FILE *);
int test_grammar();


#endif // ASSEMBLER_H_INCLUDED
