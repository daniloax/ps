#include <stdio.h>
#include <unistd.h>
#include "assembler/assembler.h"
#include "tests/Test_Suite_1.h"

void init_all(char *, char *);
void close_all();
void launch_error(char *);

/*
 Fun��o principal do programa.

*/
int main(int argc, char **argv){

    char *input_asm; // arquivo .asm de entrada (input)
    char *output_obj; //arquivo .o de saida (output)
    int c;

    while((c= getopt(argc, argv, "c:o:")) != -1){
        //leitura dos arqgumentos de entrada pela funcao getopt
        switch (c){
        case 'c':
            input_asm = optarg;
            break;
        case 'o':
            output_obj = optarg;
            break;
        default:
            break;
        }
    }
   //inicializa as variaveis principais do programa
   init_all(input_asm, output_obj);

   //roda o montodr ja gerando o arquivo de saida
   run_assembler();

   //encerra o montador
   close_all();

   return 0;
}

//inicializa o montador
void init_all(char *input_asm, char *input_obj){

   //abre os arquivos
   infile = fopen(input_asm, "r");
   outfile = fopen(input_obj, "w+");

   if(infile==NULL){
	 launch_error("Arquivo de entrada invalido.");
   } else if (outfile == NULL)
	  launch_error("Arquivo de saida obj invalido.");

   //abre o parser automatico
   load_parser();
   printf("parser loaded ..... \n");
   //carrega as variaveis necessarias para o assembler
   load_assembler();
   printf("assembler loaded .... \n");
}
//encerra os streams dos arquivos de entrada e saida.
void close_all(){
   fclose(infile);
   fclose(outfile);
}

//funcao auxiliar para encerrar o programa em casos de excecoes abruptas.
void launch_error(char *msg){

   fprintf(stderr, "ERRO: %s ", msg);

   exit(-1);
}
