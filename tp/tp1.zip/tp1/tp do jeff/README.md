# linker-assembler
This project aims to create an assembler for a hypothetical machine created in a Software System course ministered at University of Brasilia
