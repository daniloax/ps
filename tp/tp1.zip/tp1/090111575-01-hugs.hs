--EDUARDO FURTADO SA CORREA - 09/0111575

--para executar o programa basta usar o comando "main" no interpretador hugs. o arquivo de entrada padrao se assume estar na mesma pasta e ser chamado "090111575-01-hugs.c"

--programa em Hugs que le um arquivo texto contendo um programa C e executa, linha a linha, as seguintes acoes:
--despreza os comentários (1,0)
--identifica e imprime operadores aritméticos (1,0)
--identifica e imprime operadores lógicos (1,0)
--identifica e imprime operadores relacionais (1,0)
--identifica e imprime palavras reservadas (2,0)
--identifica e imprime identificadores (nomes de variáveis ou funções) do programa (2,0).
--documentação (1,0)

import System.IO
import Data.Word

-- funcao principal
main = do
	lista_de_linhas <- readFile input_file
	putStrLn (fazerAnaliseLexicaOuter (lines lista_de_linhas))
	where input_file = "090111575-01-hugs.c"

-- listas auxiliares pra fazer comparacoes e idenficar os tokens
pontuadores             = ",;:(){}[]"
digitos                 = "0123456789"
inicio_de_tokens        = "_aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ"
operadores_aritimeticos = ["=","+","++","-","--","*","/","%"]
operadores_logicos      = ["!","&&","||","^"]
operadores_relacionais  = ["==","!=",">",">=","<","<="]
palavras_reservadas = [
	"auto",        "double",      "int",         "struct",
    "break",       "else",        "long",        "switch",
    "case",        "enum",        "register",    "typedef",
    "char",        "extern",      "return",      "union",
    "const",       "float",       "short",       "unsigned",
    "continue",    "for",         "signed",      "void",
    "default",     "goto",        "sizeof",
   	"do",          "if",          "static",      "while"]

-- Caso geral da funcao buscaElementoEmLista.
--	elemento: Elemento sendo procurado numa lista.
--	cabeca: Elemento do topo de uma lista onde um elemento esta sendo procurado.
--	cauda: lista_de_linhas_tail de uma lista onde um elemento esta sendo procurado.
buscaElementoEmLista elemento (cabeca:cauda)
	| elemento == cabeca = True
	| otherwise = buscaElementoEmLista elemento cauda

-- Caso base da funcao buscaElementoEmLista.
buscaElementoEmLista _ [] = False

-- Funcao que retorna uma string com a analise lexica.
--	linhas: Lista de String com o conteudo do arquivo C de entrada.
fazerAnaliseLexicaOuter lista_de_linhas = fazerAnaliseLexica lista_de_linhas 1

-- Funcao para realizar a analise lexica.
--	lista_de_linhas_head: String com a linha que sera analisada.
--	lista_de_linhas_tail: Lista de String com o lista_de_linhas_tail das lista_de_linhas que ainda serao analisadas.
--	linha_counter: Numero da linha atual.
-- condição de parada
fazerAnaliseLexica [] _ = ""
fazerAnaliseLexica (lista_de_linhas_head:lista_de_linhas_tail) linha_counter = let analiseLexicaLinha = fazerAnaliseLexicaLinha lista_de_linhas_head "" "" in
		(	if analiseLexicaLinha == "" then
				""
			else
				"linha " ++ show linha_counter ++ ": '" ++ lista_de_linhas_head ++ "'\n" ++ analiseLexicaLinha ++
				(if lista_de_linhas_tail == [] then "" else "\n")
		) ++ fazerAnaliseLexica lista_de_linhas_tail (linha_counter + 1)

--  Funcao para fazer a analise lexica de uma linha.
--	cabecaLinha: Primeiro caractere da linha a ser analisada.
--	caudaLinha: Todos os outros caracteres depois do primeiro na linha.
--	analiseAtual: String com o a analise que ja foi feita na linha.
--	tokenAtual: Token que esta sendo lido na linha.
fazerAnaliseLexicaLinha "" analiseAtual tokenAtual = (analiseAtual ++ analisarToken tokenAtual)
fazerAnaliseLexicaLinha (cabecaLinha:caudaLinha) analiseAtual tokenAtual
	-- espacos ou tabulacoes
	| cabecaLinha == ' ' || cabecaLinha == '\t' = (
		fazerAnaliseLexicaLinha caudaLinha (analiseAtual ++ analisarToken tokenAtual) ""
	)

	-- pontuadores
	| buscaElementoEmLista cabecaLinha pontuadores = (
		fazerAnaliseLexicaLinha caudaLinha (analiseAtual ++ analisarToken tokenAtual ++ analisarToken [cabecaLinha]) ""
	)

	-- comentarios de uma linha com //
	| cabecaLinha == '/' = (
		let
			checaBarra pescocoLinha
				-- Retorna a analise da linha ao encontrar comentario unilinha.
				| pescocoLinha == '/' =
					(analiseAtual ++ analisarToken tokenAtual)

				-- Continua a analise da linha ao encontrar comentario multilinha, que pode terminar na mesma linha.
				| pescocoLinha == '*' =
					fazerAnaliseLexicaLinha (tail caudaLinha) (analiseAtual ++ analisarToken tokenAtual) ""

				-- Continua a analise concatenando a analise de uma barra de divisao (operador aritmetico).
				| otherwise =
					fazerAnaliseLexicaLinha caudaLinha (analiseAtual ++ analisarToken tokenAtual ++ analisarToken "/") ""
		in
			-- Caso a barra tenho sido o ultimo caractere da linha.
			if caudaLinha == "" then
				(analiseAtual ++ analisarToken tokenAtual ++ analisarToken "/")

			-- Caso ainda hajam caracteres na linha.
			else
				checaBarra (head caudaLinha)
	)

	-- operadores
	| buscaElementoEmLista [cabecaLinha] operadores_aritimeticos || buscaElementoEmLista [cabecaLinha] operadores_logicos || buscaElementoEmLista [cabecaLinha] operadores_relacionais || cabecaLinha == '&' || cabecaLinha == '|' = (
		-- Caso tenha sido o ultimo caractere da linha.
		if caudaLinha == "" then
			(analiseAtual ++ analisarToken tokenAtual ++ analisarToken [cabecaLinha])

		-- Caso ainda hajam caracterese na linha.
		else
			-- Caso seja um operador de dois caracteres.
			if buscaElementoEmLista ([cabecaLinha] ++ [head caudaLinha]) operadores_aritimeticos || buscaElementoEmLista ([cabecaLinha] ++ [head caudaLinha]) operadores_logicos || buscaElementoEmLista ([cabecaLinha] ++ [head caudaLinha]) operadores_relacionais then
				fazerAnaliseLexicaLinha (tail caudaLinha) (analiseAtual ++ analisarToken tokenAtual ++ analisarToken (cabecaLinha:(head caudaLinha):[])) ""

			-- Caso seja um operador de apenas um caracter.
			else
				fazerAnaliseLexicaLinha caudaLinha (analiseAtual ++ analisarToken tokenAtual ++ analisarToken [cabecaLinha]) ""
	)

	-- caso geral
	| otherwise =
		fazerAnaliseLexicaLinha caudaLinha analiseAtual (tokenAtual ++ [cabecaLinha])

-- Funcao que testa o tipo do token e o retorna no formato String.
--	cabecaToken: Primeiro caractere do token.
--	caudaToken: Todos os outros caracteres que vem depois do primeiro no token.
analisarToken "" = ""
analisarToken (cabecaToken:caudaToken)
	| buscaElementoEmLista (cabecaToken:caudaToken) operadores_aritimeticos = (cabecaToken:caudaToken) ++ " - operador aritmetico.\n"
	| buscaElementoEmLista (cabecaToken:caudaToken) operadores_logicos = (cabecaToken:caudaToken) ++ " - operador logico.\n"
	| buscaElementoEmLista (cabecaToken:caudaToken) operadores_relacionais = (cabecaToken:caudaToken) ++ " - operador relacional.\n"
	| buscaElementoEmLista cabecaToken pontuadores = (cabecaToken:caudaToken) ++ " - pontuador.\n"
	| buscaElementoEmLista cabecaToken digitos = (cabecaToken:caudaToken) ++ " - constante numerica.\n"
	| buscaElementoEmLista (cabecaToken:caudaToken) palavras_reservadas = (cabecaToken:caudaToken) ++ " - palavra reservada.\n"
	| buscaElementoEmLista cabecaToken inicio_de_tokens = (cabecaToken:caudaToken) ++ " - identificador.\n"
	| otherwise = ""