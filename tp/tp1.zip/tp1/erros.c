/* Testar erros:

	Léxico: Token invalido
	Sintático: Não é uma expressão válida na gramática
	Semântico: Ao relacionar uma linha com outra linha da erro
	
	obs: em uma linha pode ter mais de um erro, disse o professor hoje, mas vamos manter a simplicidade
	

*/

/* IMPRIMIR O TIPO DE ERRO E QUAL A LINHA */
int g_contador_de_linhas = 1;
g_error_flag = 0;
SINTÁTICO/LÉXICO/SEMANTICO
/*** ERRO LEXICO ***/
/* 1 - tokens invalidos; -> erro LÉXICO  */


/*** ERRO SINTATICO ***/
/* 1 - diretivas invalidas;  pode ser erro lexico ou sintatico -> erro SINTATICO*/
/* 2 - instrucoes invalidas; erro SINTATICO*/
{ dois rotulos na mesma linha;

/*** ERRO SEMANTICO ***/
/* 1 - modificacao de um valor constante. erro -> SEMANTICO/TALVEZ LEXICO SE MUDAREM PRA UM VALOR COM TOKEN INVALIDO */
/* 2 - declaracoes ausentes; erro -> SEMANTICO/TALVEZ LEXICO SE MUDAREM PRA UM VALOR COM TOKEN INVALIDO */
CIRO main.c linha 119 printf("\nErro! Declaracao de %s ausente. Na linha: %d",simbolo, nl);

/* 3 - declaracoes repetidas; SEMANTICO/TALVEZ LEXICO SE MUDAREM PRA UM VALOR COM TOKEN INVALIDO */
/* 4 - pulo para rotulos invalidos; SEMANTICO/TALVEZ LEXICO SE MUDAREM PRA UM VALOR COM TOKEN INVALIDO */
/* 5 - rotulos repetidos; SEMANTICO/TALVEZ LEXICO SE MUDAREM PRA UM VALOR COM TOKEN INVALIDO */

/* { diretivas ou instrucoes na secao errada erro -> SEMANTICO/TALVEZ LEXICO SE MUDAREM PRA UM VALOR COM TOKEN INVALIDO
		Não pode ter instrucoes no SECTION DATA
		Não pode ter diretivas que não sejam SPACE e CONST e END no SECTION DATA
		Não pode ter SPACE e CONST no SECTION TEXT
		Não pode ter END antes de SECTION DATA
		Tem que ter END depois de SECTION DATA
		Não pode ter BEGIN e STOP depois de SECTION DATA
		Tem que ter BEGIN e STOP depois de SECTION TEXT e antes de SECTION DATA
		Tem que ter STOP 
		
		Só precisa ter SECTION DATA se tiver rotulos que devem estar abaixo de SECTION DATA
		
{ divisao por zero; erro->SEMANTICO
{ instrucoes com a quantidade de operando invalida; erro->SINTATICO



{ secao (TEXT ou DATA) faltante; erro->SEMANTICO
restricao: soh preciso ter o TEXT, soh preciso do DATA se tem algum  label no text que precisa de uma declaracao no data

{ secao invalida; erro->SINTATICO/TALVEZ LEXICO SE DETECTAR TOKEN INVALIDO

{ tipo de argumento invalido; erro->SINTATICO/TALVEZ LEXICO SE DETECTAR TOKEN INVALIDO
            if(op1!=NULL)
                printf("operand1: %s ", op1);
            if(op2!=NULL)
                printf("operand2: %s ", op2);

            printf("\n");
        }
        else
        {
            printf("ERRO sintatico na linha %d", g_contador_de_linhas);
        }
{ endereco de memoria nao reservado; erro->SEMANTICO


*/