/* José tentando fazer as funcoes 
has_inst
get_inst_size
has_dir
get_dir_size
de acordo com a getInstrucaoOuDiretivaCodByMnemonico*/

int hasInstrucaoOuDiretiva(char param_mnemonico[10]);
int hasDiretiva(char diretiva);
int getInstrucaoOuDiretivaOrDiretivaSizeByMnemonico(char param_mnemonico[10]);


/* Verifica se a instrucao ou Diretiva que existe na tabela de instrucoes e diretivas é um mnemonico, se sim retorna 1, se não retorna 0 */
int hasInstrucaoOuDiretivaByMnemonico(char param_mnemonico[10])
{
    int i;
    for( i =0; instrucao < QTD_INSTRUCOES_E_DIRETIVAS; ++i)
    {
        /*se encontrar, retorno 1.*/
        if(iStringCompare(g_tabela_de_instrucoes_e_diretivas[i].mnemonico, param_mnemonico)==0)
            return 1;
    }
    /*retorno 0 porque não encontrei.*/
    return 0;
}



/