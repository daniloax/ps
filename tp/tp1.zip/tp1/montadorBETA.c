/*compilação para eduardo:
cd C:\Dropbox\CURSOS\SB\tp1
cls & gcc.exe -std=c11 montador.c -o montador -Wall & montador.exe modulo_a modulo_a_saida
//montador.exe modulo_a modulo_a_saida
*/

/*programa desenvolvido em OS windows 8.1 x64 (eduardo) com compilador gcc.exe (GCC) 4.8.1 instalado através do pacote MinGW*/


#include <stdio.h>
/*para usar funcoes como strcpy, strcat*/
#include <string.h>
#include <stdlib.h>
/*para usar a função tolower*/
#include <ctype.h>

#define IDEN_MAX 100
#define QTD_INSTRUCOES_E_DIRETIVAS 23

/***************** funções *****************/
/*case insentitive string comparison*/
/*retorna 1 se as strings comparadas são iguais*/
/*retorna 0 se as strings comparadas NÃO são iguais*/
int iStringCompare(char string1[], char string2[]);
void strToLower(char reference_to_string[]);
int processaRotulo(char linha[], int contador_de_posicoes);
int processaInstrucao(int coluna, char linha[], int *contador_de_posicoes);
int getInstructionCodByMnemonico(char param_mnemonico[10]);


struct struct_tabela_de_instrucoes_e_diretivas{
    char mnemonico[10];
    int operandos;
    int cod;
    /*tamanho em bytes*/
    int tamanho;
}Struct_tabela_de_instrucoes_e_diretivas;

struct struct_tabela_de_simbolos{
    char simbolo[IDEN_MAX];
    int valor;
    /*byte que representa se o simbolo é externo ou não*/
    char externo;
}Struct_tabela_de_simbolos;

struct struct_tabela_de_definicoes{
    char simbolo[IDEN_MAX];
    int valor;
}Struct_tabela_de_definicoes;

struct struct_tabela_de_uso{
    char simbolo[IDEN_MAX];
    int endereco;
}Struct_tabela_de_uso;

/**** variaveis globais que tem um g_ na frente ****/
/*tabela_de_instrucoes_e_diretivas: contém os opcodes simbólicos acompanhadas das informações para gerar código de máquina*/
struct struct_tabela_de_instrucoes_e_diretivas g_tabela_de_instrucoes_e_diretivas[QTD_INSTRUCOES_E_DIRETIVAS];
/*tabela_de_simbolos: contém todos os símbolos definidos no programa e seus
                      atributos, onde um símbolo é um rótulo ou o nome de uma
                      variável declarada com um nome simbólico*/
struct struct_tabela_de_simbolos g_tabela_de_simbolos[200];
/*contador da quantidade de simbolos na tabela de símbolos*/
int g_qtd_de_simbolos = 0;

/*Tabela de Uso: indica os símbolos externos utilizados no módulo.*/
struct struct_tabela_de_uso g_tabela_de_uso[100];

/*Tabela de Definições: indica os símbolos públicos e seus atributos (é uma fração da Tabela de Simbolos)*/
struct struct_tabela_de_definicoes g_tabela_de_definicoes[100];

/*contador de linha que está sendo lida no momento, útil para imprimir mensagens de erros*/
int g_contador_de_linhas = 1;

char g_error_flag = 0;

// do ciro:
char s[IDEN_MAX][IDEN_MAX];

char instrucao[50];
char binary[50];


/*case insentitive string comparison*/
/*retorna 1 se as strings comparadas são iguais*/
/*retorna 0 se as strings comparadas NÃO são iguais*/
int iStringCompare(char string1[], char string2[]){
    strToLower(string1);
    strToLower(string2);
    if(strcmp(string1, string2)==0)
        return 1;
    else
        return 0;
}

void strToLower(char reference_to_string[]){
    int i=0;
    while(reference_to_string[i]!=0)
    {
        reference_to_string[i] = tolower(reference_to_string[i]);
        i++;
    }
}

int processaRotulo(char linha[], int contador_de_posicoes){
    int coluna                   = 0;
    int coluna_for_return        = 0;
    int coluna_do_simbolo_extern = 0;
    int i                        = 0;
    int simbolo_novo_flag        = 1;
    char simbolo[IDEN_MAX];
    char simbolo_extern[IDEN_MAX];
    int is_extern                = 0;
    char CONST_STRING_EXTERN[7]        = "extern";

    /*monto a variavel símbolo com o token da variavel ou rótulo sendo processado*/
    /*e posiciono o ponteiro da coluna na posição do ':'*/
    while (linha[coluna] != ':')
    {
        simbolo[coluna] = linha[coluna];
        coluna++;
    }
    /*substituo o ':' por um caracter nulo, para indicar o fim da string. Terei o token do rótulo isolado.*/
    simbolo[coluna] = '\0';

    /*identifica se o simbolo seguinte ao rótulo é a diretiva EXTERN*/
    /*se o caractere seguinte é um espaço em branco inutil, salta ele. o do while ao invés de um while, garante que salto o ':', que é onde havia parado o ponteiro*/
    do
    {
        coluna++;
    } while ( (linha[coluna] == ' ') || (linha[coluna] == '\t') );
    /*guardo o valor da coluna que vou retornar no final em uma variável auxiliar, pra que eu possa seguir utilizando coluna pra identificar o token seguinte, se for extern.*/
    coluna_for_return = coluna;

    /*separa a string seguinte, para comparar depois*/
    while ( (linha[coluna] != ' ') && (linha[coluna] != '\t') && (linha[coluna] != '\n') && (linha[coluna] != '\0') && (linha[coluna] != '\r') && (linha[coluna] != 0) )
    {
        simbolo_extern[coluna_do_simbolo_extern] = linha[coluna];
        coluna++;
        coluna_do_simbolo_extern++;
        // printf("\ncoluna:%d",coluna );
    }
    /*substituo o ' ', '\t' ou '\n' por um caracter nulo, para indicar o fim da string. Terei o possível extern token isolado.*/
    simbolo_extern[coluna_do_simbolo_extern] = '\0';
    /*compara pra ver se é extern*/
    if( iStringCompare(simbolo_extern, CONST_STRING_EXTERN) )
        is_extern = 1;

    for ( ; i <= g_qtd_de_simbolos; i++)
    {
        /*verifica se o simbolo já está na tabela de simbolos*/
        if( iStringCompare(g_tabela_de_simbolos[i].simbolo, simbolo) )
        {
            g_error_flag = 1;
            simbolo_novo_flag = 0;
            printf("\nl:%d. Erro <tipo do erro>. O simbolo ja existe na tabela de simbolos.", g_contador_de_linhas);
        }
    }

    /*adiciona o novo simbolo à tabela de simbolos*/
    if( simbolo_novo_flag == 1 )
    {
        /*o simbolo em si*/
        strcpy( g_tabela_de_simbolos[g_qtd_de_simbolos].simbolo, simbolo );
        /*se é externo ou não.*/
        g_tabela_de_simbolos[g_qtd_de_simbolos].externo = is_extern;

        g_tabela_de_simbolos[g_qtd_de_simbolos].valor = contador_de_posicoes;
        /*incremento o contador da quantidade de simbolos na tabela de simbolos*/
        g_qtd_de_simbolos++;
    }

    /*retorno o ponteiro de colunas da linha lida duas posições a frente*/
    return coluna_for_return;
}

int processaInstrucao(int coluna, char linha[], int *contador_de_posicoes){
    int i;
    int coluna_offset = 0;
    int flag_token_found = 0;
    // int error_flag = 0;
    char instrucao[IDEN_MAX];
    int vetor_counter = 0;
    char tamanho_de_vetor_string[100];
    int tamanho_do_vetor_int;

    printf("\nna funcao processa Instrucao\n");

    /*coloca o token de uma instrução em uma variavel*/
    while((linha[coluna+coluna_offset] != '\0') && (linha[coluna+coluna_offset] != ' ') && (linha[coluna+coluna_offset] != '\n') && (linha[coluna+coluna_offset] != '\t'))
    {
        instrucao[coluna_offset] = linha[coluna+coluna_offset];
        coluna_offset++;
    }
    /*substituo o último caracter pelo caractér nulo, para marcar o fim da string*/
    instrucao[coluna_offset]='\0';

    printf("com: -%s-\n",instrucao );

    for( i=0; i < QTD_INSTRUCOES_E_DIRETIVAS; i++ )
    {
        // printf("\ncomparando -%s- com -%s-", g_tabela_de_instrucoes_e_diretivas[i].mnemonico, instrucao);
        if(iStringCompare(g_tabela_de_instrucoes_e_diretivas[i].mnemonico, instrucao)){
                *contador_de_posicoes = *contador_de_posicoes + g_tabela_de_instrucoes_e_diretivas[i].tamanho;
                flag_token_found = 1;
        }
    }

    /*identifico a diretiva space*/
    if(iStringCompare(g_tabela_de_instrucoes_e_diretivas[15].mnemonico, instrucao))
    {
        /*procedo para verificar se trata-se de um space sozinho ou seguido do número de espaços a reservar (vetor)*/
        if((linha[coluna+coluna_offset]!='\0') && (linha[coluna+coluna_offset+1]!='0'))\
        {
            while((linha[coluna_offset+coluna+1+vetor_counter] != '\0') && (linha[coluna_offset+coluna+1+vetor_counter] != '\n')){
                tamanho_de_vetor_string[vetor_counter] = linha[coluna_offset+coluna+1+vetor_counter];
                vetor_counter++;
            }
            tamanho_de_vetor_string[vetor_counter] = '\0';
            /*uso atoi para converter de string para int*/
            tamanho_do_vetor_int = atoi(tamanho_de_vetor_string);
            /*atualizo o contador de posicoes para levar em consideracao o vetor*/
            *contador_de_posicoes = *contador_de_posicoes + tamanho_do_vetor_int -1;
        }
    }


    if (flag_token_found == 0)
    {
        printf("\nl:%d. Erro lexico. Operacao '%s' nao consta la tabela de instrucoes e diretivas.", g_contador_de_linhas, instrucao);
        g_error_flag = 1;
        // error_flag = 1;
    }

    return coluna+coluna_offset;
}

/*pra cada entrada da tabela global de instruções e diretivas a cada iteração, compara a string de entrada*/
/*com alguma da tabela. Retorna o valor do código dela quando encontrar, ou -1 no caso de nunca encontrar o que buscava.*/
int getInstructionCodByMnemonico(char param_mnemonico[10])
{
    int i;
    for (i = 0; i < QTD_INSTRUCOES_E_DIRETIVAS; ++i)
    {
        if (iStringCompare(g_tabela_de_instrucoes_e_diretivas[i].mnemonico, param_mnemonico))
            return g_tabela_de_instrucoes_e_diretivas[i].cod;
    }

    /*retorna -1 em caso de nunca encontrar o que buscava.*/
    return -1;
}

int main (int argc, char *argv[])
{
	FILE * arquivo_de_entrada_asm;
	FILE * arquivo_de_entrada_pre_processado;
	FILE * arquivo_de_saida_o;
	FILE * arquivo_instrucoes_e_diretivas;

	/*nome dos arquivos de entrada e saida*/
	char nome_do_arquivo_de_entrada[200];
	char nome_do_arquivo_de_entrada_pre_processado[200];
	char nome_do_arquivo_de_saida[200];

	/*variavel auxiliar, usada para armazenar caracteres lidos de arquivos*/
	char c;

    /*contador_de_posicoes ou location counter: indica a posição de memória a ser ocupada (preenchida) pelo código de máquina.*/
    int contador_de_posicoes = 0;

    /*variável para guardar o comprimento de strings*/
    int string_length;

    /*string onde armazeno as linhas obtidas do arquivo de código fonte*/
    char linha_lida[300];

    /*string onde armazeno um único token para ver se matchea com palavras reservadas, por exemplo PUBLIC*/
    char* token = NULL;

    char CONST_STRING_PUBLIC[8] = "PUBLIC";

    /*iteradores*/
	unsigned int i;
    unsigned int coluna = 0;
    unsigned int k;

    /*flags*/
    char token_public_found_flag = 0;

    /*váriaveis usadas na segunda passagem*/
    int flag_tem_rotulo      = 0;
    char* rotulo = NULL;
    /*operacao guarda a instrução, exemplo: 'COPY'*/
    char* operacao = NULL;
    /*nos operando guardo os "parametros", exemplo o que tá em maiusculo: "copy OP1, OP2"*/
    char* operando1 = NULL;
    char* operando2 = NULL;
    char CONST_STRING_STOP[6] = "stop";
    char flag_stop_instruction_found = 0;

	// variaveis do ciro
    // int v[IDEN_MAX];

	/*verifica se os parametros de entrada são válidos*/
   	if(argc != 3)
    {
        printf("\nPrograma requer dois parametros: ArquivoDeEntradaComExtensao.asm ArquivoDeSaidaComExtensao.o\n");
        printf("Entre apenas o nome dos arquivos, ja que se assume a extensao\n");
        exit(EXIT_FAILURE);
    }

    /*pega dos parametros de entrada do programa o nome dos arquivos de entrada e saida*/
	strcpy(nome_do_arquivo_de_entrada, argv[1]);
	strcat(nome_do_arquivo_de_entrada, ".asm");
	strcpy(nome_do_arquivo_de_entrada_pre_processado, argv[1]);
	strcat(nome_do_arquivo_de_entrada_pre_processado, "_pre_processado.asm");
	strcpy(nome_do_arquivo_de_saida, argv[2]);
	strcat(nome_do_arquivo_de_saida, ".o");

	/*abre o arquivo de entrada para leitura*/
	arquivo_de_entrada_asm = fopen(nome_do_arquivo_de_entrada, "r");
	if ( arquivo_de_entrada_asm == NULL)
    {
		printf("\nFalha ao abrir arquivo de entrada: %s. \n",nome_do_arquivo_de_entrada);
        exit(EXIT_FAILURE);
	}

	/*abre o arquivo que tem a tabela de instrucoes e diretivas*/
	arquivo_instrucoes_e_diretivas = fopen("tabela_de_instrucoes_e_diretivas", "r");
	if ( arquivo_instrucoes_e_diretivas == NULL)
    {
		printf("\nFalha ao abrir arquivo de tabela_de_instrucoes_e_diretivas que deve estar na mesma pasta do executavel.\n");
        exit(EXIT_FAILURE);
	}

	/*uso o arquivo de instruções e diretivas para criar uma tabela em memória*/
	i = 0;
	while((c = fscanf
		(
		arquivo_instrucoes_e_diretivas,
		"%s %d %d %d",
			g_tabela_de_instrucoes_e_diretivas[i].mnemonico,
			&g_tabela_de_instrucoes_e_diretivas[i].operandos,
			&g_tabela_de_instrucoes_e_diretivas[i].cod,
			&g_tabela_de_instrucoes_e_diretivas[i].tamanho
		)
	)!= EOF)
	{
    	i++;
    }
    fclose(arquivo_instrucoes_e_diretivas);

	/*abre o arquivo de saida para escritura*/
	arquivo_de_saida_o = fopen(nome_do_arquivo_de_saida, "w+");
	if ( arquivo_de_saida_o == NULL)
    {
		printf("\nFalha ao criar arquivo de saida: %s. \n",nome_do_arquivo_de_saida);
        exit(EXIT_FAILURE);
	}

	/*abre para escritura um arquivo para o output do pre processamento*/
	/*este arquivo de pre processamente vai ter o mesmo assembly de entrada, mas com coisas inúteis para o montador,*/
	/*como comentários, removidos*/
	arquivo_de_entrada_pre_processado = fopen(nome_do_arquivo_de_entrada_pre_processado, "w+");
	if ( arquivo_de_entrada_pre_processado == NULL)
    {
		printf("\nFalha ao criar arquivo de saida para o output do pre processamento: %s. \n", nome_do_arquivo_de_entrada_pre_processado);
        exit(EXIT_FAILURE);
	}

	printf("\nHello SB!\n");

    //Inicia o pré processamento identificando os Equals
	i = 1;
	/*Isso é do ciro. Se ve que no trabalho dele tinha os mnem^onicos EQU e IFS, enquanto no nosso temos EXTERN e PUBLIC de extras.
	deixo o código aqui comentado para DELETAR no final, porque tenho o pressentimento de que talvez venh a ser útil pro nosso caso.*/
    // do
    // {
    //     fscanf(arquivo_de_entrada_asm, "%s", s[0]);
    //     printf("s[0]: %s\n",&s[0]);
    //     string_length = strlen(s[0]);
    //     if(s[0][string_length-1]==':'){
    //         fscanf(arquivo_de_entrada_asm, "%s", s[IDEN_MAX-1]);;
    //         printf("s[IDEN_MAX-1][0]: %s\n",&s[IDEN_MAX-1]);
    //         if(s[IDEN_MAX-1][0]=='E'){
    //         	printf("E \n");
    //             fscanf(arquivo_de_entrada_asm, "%d", &v[i]);
    //             strcpy(s[i], s[0]);
    //             s[i][string_length-1] = 00;
    //             i++;
    //         }
    //     }
    // } while((c = fgetc(arquivo_de_entrada_asm))!= EOF);
	// rewind(arquivo_de_entrada_asm);


    /*PREPROCESSAMENTO*/
    while(((c = fgetc(arquivo_de_entrada_asm))!= EOF))
    {
    	/*verifica se é um comentário*/
        if(c==';')
        {
        	/*se é um comentário, leio até o fim da linha, com intenção de descartar os chars lidos e escrever apenas o salto de linha*/
            do
            {
                c = fgetc(arquivo_de_entrada_asm);
            } while((c != '\n'));
            fputc(c, arquivo_de_entrada_pre_processado);
        }
        /*se não é comentário no código*/
        else
        {
            coluna=0;
            // ainda não entendi bem essa porção de código do ciro.
            s[i][coluna] = c;

            /*se é um caracter diferente de espaço ou EOF, escrevo ele no arquivo de saída do pré-processamento*/
            while( (c = fgetc(arquivo_de_entrada_asm)) && (c != EOF) )
            {
                coluna++;
                s[i][coluna] = c;
            }
            s[i][coluna+1] = 00;
        	fprintf(arquivo_de_entrada_pre_processado, "%s", s[i]);
        }
    }
    /*termino o pré-processamento fechando o de entrada ORÍGINAL, do qual usei para gerar o pré-processado.*/
    fclose(arquivo_de_entrada_asm);


    /**************************************** primeira passagem: a construção da Tabela de Símbolos ****************************************/
    rewind(arquivo_de_entrada_pre_processado);
    g_contador_de_linhas = 1;
    contador_de_posicoes = 0;
    while( (c = fgetc(arquivo_de_entrada_pre_processado))!= EOF)
    {
        token_public_found_flag = 0;

        /*ignoro caracteres de espaços inúteis*/
        if((c!=' ') && (c!='\n') && (c!='\t'))
        {
            /*obtenho uma linha do código fonte com o do{}while(); abaixo*/
            i = 0;
            /*o caractere nulo aqui é apenas um bug proof. Talvez nem seja necessário, já que (sempre?) vai ser pisado logo abaixo*/
            linha_lida[0]='\0';
            do
            {
                linha_lida[i] = c;
                c = fgetc(arquivo_de_entrada_pre_processado);
                i++;
            } while((c != '\n') && (c!= EOF));
            /*substituo o \n ou EOF pelo caractere nulo no final da string para indicar o fim dela e poder usar a função strlen*/
            linha_lida[i]='\0';

            /*verifico o tamanho da linha obtida*/
            string_length = strlen(linha_lida);
            coluna=0;
            /*se tem algo na linha lida*/
            if(string_length > 0)
            {
                /*processamento de símbolo*/
                /*limpo a variável token. Se isso for usado em outro lado, refatorar para uma função*/
                for (k = 0; k < IDEN_MAX; k++)
                {
                    token[k] = '\0';
                }
                /*Separo o primeiro token em busca de um rótulo ou variavel*/
                while( (linha_lida[coluna] != ' ') && (linha_lida[coluna] != '\n') && (linha_lida[coluna] != '\t') )
                {
                    /*copio os caracteres lidos para uma variavel token, para buscar pelo token PUBLIC depois*/
                    token[coluna] = linha_lida[coluna];
                    coluna++;
                }
// printf("\nl:%d token: -%s-",g_contador_de_linhas, &token);
                /*verifico o último caractere do token. ':' indica que é um rótulo ou variável*/
                if(linha_lida[coluna-1]==':')
                    coluna = processaRotulo(linha_lida, contador_de_posicoes);
                /*verifico se o token é PUBLIC, para adicionar à tabela de definições.*/
                else if (iStringCompare(token, CONST_STRING_PUBLIC))
                {
                    /*token public encontrado. adiciono ele à tabela de definições.*/
                    /*set flag em true*/
                    token_public_found_flag = 1;
                }
                /*no caso de não encontrar o token PUBLIC ou o token de um rótulo ou variável, volto o ponteiro de posição na linha para o início, assim posso verificar o token como instrução*/
                else
                    coluna = 0;

// printf("\t\tprocessando token: -%s-", &token);
                /*processamento de instrucao*/
                /*se encontrei um token PUBLIC não devo processar o token seguinte, porque ele só faz sentido para o ligador*/
                if ( token_public_found_flag == 0 )
                {
                    /*salta caracteres inúteis com o while*/
                    while( (linha_lida[coluna] == ' ') || (linha_lida[coluna] == '\t') )
                        coluna++;

                    /*processa o primeiro token da linha ou o próximo token a um rótulo, variável*/
                    coluna = processaInstrucao(coluna, linha_lida, &contador_de_posicoes);
                }
            }
            g_contador_de_linhas++;

            /*se era uma linha vazia, como por exemplo uma linha que antes tinha um comentário, ignoro mas conto ela:*/
        }else if(c == '\n')
            g_contador_de_linhas++;
    }

    /*debug: verifico o que tenho na tabela de simbolos*/
    printf("\n\ndebug: print da tabela de simbolos:");
    printf("\nsimbolo\t|\tvalor\t|\texterno");
    printf("\n--------|---------------|---------------");
    for (i = 0; i < 200; ++i)
    {
        if ( strlen(g_tabela_de_simbolos[i].simbolo) > 0)
        {
            printf("\n.%s.", g_tabela_de_simbolos[i].simbolo);
            printf("\t|\t.%d.", g_tabela_de_simbolos[i].valor);
            printf("\t|\t.%d.", g_tabela_de_simbolos[i].externo);
        }
    }

    /*debug: verifico o que tenho na tabela de simbolos*/
    printf("\n\ndebug: print da tabela de instrucoes e diretivas:");
    printf("\nmnemonico|  operandos\t|\tcod\t|\ttamanho");
    printf("\n--------|---------------|---------------|------------------");
    for (i = 0; i < QTD_INSTRUCOES_E_DIRETIVAS; ++i)
    {
        printf("\n%s", g_tabela_de_instrucoes_e_diretivas[i].mnemonico);
        printf("\t|\t.%d.", g_tabela_de_instrucoes_e_diretivas[i].operandos);
        printf("\t|\t.%d.", g_tabela_de_instrucoes_e_diretivas[i].cod);
        printf("\t|\t.%d.", g_tabela_de_instrucoes_e_diretivas[i].tamanho);
    }

    /*debug: verifico o que tenho na tabela de simbolos*/
    printf("\n\ndebug: print da tabela de definicoes:");
    printf("\nsimbolo\t|\tvalor");
    printf("\n--------|---------------");
    for (i = 0; i < 100; ++i)
    {
        if ( strlen(g_tabela_de_definicoes[i].simbolo) > 0)
        {
            printf("\n.%s.", g_tabela_de_definicoes[i].simbolo);
            printf("\t|\t.%d.", g_tabela_de_definicoes[i].valor);
        }
    }

    /*debug: verifico o que tenho na tabela de simbolos*/
    printf("\n\ndebug: print da tabela de definicoes:");
    printf("\nsimbolo\t|\tendereco");
    printf("\n--------|---------------");
    for (i = 0; i < 100; ++i)
    {
        if ( strlen(g_tabela_de_uso[i].simbolo) > 0)
        {
            printf("\n.%s.", g_tabela_de_uso[i].simbolo);
            printf("\t|\t.%d.", g_tabela_de_uso[i].endereco);
        }
    }

    /**************************************** segunda passagem ****************************************/
    printf("\n***** Segunda passagem *****\n");
    rewind(arquivo_de_entrada_pre_processado);
    g_contador_de_linhas = 1;
    contador_de_posicoes = 0;
    while( (c = fgetc(arquivo_de_entrada_pre_processado))!= EOF)
    {
        if((c!=' ') && (c!='\n') && (c!='\t'))
        {
            // Para cada operando que é símbolo
            // Procura operando na TS
            //     Se não achou: Erro, símbolo indefinido
            // Procura operação na tabela de instruções
            // Se achou:
            //     contador_posição = contador_posição + tamanho da instrução
            //     Se número e tipo dos operandos está correto então
            //         gera código objeto conforme formato da instrução
            //     Senão
            //         Erro, operando inválido
            // Senão:
            //     Procura operação na tabela de diretivas
            //     Se achou:
            //         Chama subrotina que executa a diretiva
            //         Contador_posição = valor retornado pela subrotina
            //     Senão:
            //         Erro, operação não identificada
            g_contador_de_linhas++;

            /*obtenho uma linha do código fonte com o do{}while(); abaixo*/
            i = 0;
            /*o caractere nulo aqui é apenas um bug proof. Talvez nem seja necessário, já que (sempre?) vai ser pisado logo abaixo*/
            linha_lida[0]='\0';
            do
            {
                linha_lida[i] = c;
                c = fgetc(arquivo_de_entrada_pre_processado);
                i++;
            } while((c != '\n') && (c!= EOF));
            /*substituo o \n ou EOF pelo caractere nulo no final da string para indicar o fim dela e poder usar a função strlen*/
            linha_lida[i]='\0';

            /*verifico o tamanho da linha obtida*/
            string_length = strlen(linha_lida);
            coluna = 0;
            /*se tem algo na linha lida*/
            if(string_length > 0)
            {

                if(strchr(linha_lida, ':'))
                    flag_tem_rotulo = 1;

                /*testes da função strtok, que eu deveria ter descoberto antes..... tsc tsc..*/
                /*http://www.tutorialspoint.com/c_standard_library/c_function_strtok.htm*/
                // char string_teste[50] = "abcd-efgh!ijklm nopq";
                // char *token_res;
                // token_res = strtok(string_teste, " -!");
                // /* walk through other tokens */
                // while( token_res != NULL )
                // {
                //    printf( " %s\n", token_res );
                //    token_res = strtok(NULL, " -!");
                // }

                /*separo o primeiro token da linha lida, usando como separador espaço, tab, virgula ou dois pontos.*/
                token = strtok (linha_lida," \t,:");

                /*nulo as variáveis que uso a seguir, a cada iteração pra que não tenha problemas com lixo da iteração anterior*/
                operando1 = NULL;
                operando2 = NULL;
                rotulo    = NULL;
                operacao  = NULL;

                /*se a flag está ligada, trata-se de um rótulo, se não é um operando.*/
                if(flag_tem_rotulo)
                    rotulo = token;
                else
                    operacao = token;

                /*itero pelos tokens seguintes da linha_lida.*/
                while (token != NULL)
                {
                    token = strtok (NULL, " ,:\t");
                    if(token == NULL)
                        continue;

                    /*se eu tinha rótulo, ainda não tenho em operacao a operação, porque é o segundo token.*/
                    /*se não tinha rótulo, já tenho em operacao o que quria ter e entro no else.*/
                    if(flag_tem_rotulo)
                    {
                        operacao = token;
                        flag_tem_rotulo = 0;
                        add_symbol_list(&ts1, rotulo, pc);
                    }
                    else
                    {
                        /*ao entrar nesse else pela primeira vez, espero ter em token o primeiro operando. na segunda vez, tenho o segundo operando, e o primeir já não é mais null.*/
                        if(operando1 == NULL)
                            operando1 = token;
                        else if(operando2 == NULL)
                            operando2 = token;
                    }
                }

                /*debug*/printf("\ndebug: l:%d - ", g_contador_de_linhas);
                /*debug*/if(rotulo != NULL)
                /*debug*/{
                /*debug*/   printf("rotulo: (%s %d) ", rotulo, search_code_symbol_list(rotulo));
                /*debug*/}

                if(operacao != NULL)
                {
                    /*verifica se é a instrução STOP*/
                    if(iStringCompare(operacao, CONST_STRING_STOP))
                    {
                        /*ligo a flag flag_stop_instruction_found. há um separador de código e de dados no arquvio de entrada.*/
                        flag_stop_instruction_found = 1;
                        /*debug*/printf("operacao: %s %d  ", operacao, getInstructionCodByMnemonico(operacao));
                        add_cl(&cl, getInstructionCodByMnemonico(operacao));
                    }
                    else
                    {
                        /*debug*/printf("operacao: %s %d  ", operacao, getInstructionCodByMnemonico(operacao));

                        /* Verifica se a instrucao encontrada existe na tabela de instrucoes e diretivas.*/
                        if(has_inst(operacao))
                        {
                            pc = pc + get_inst_size(operacao);

                        }
                        /* Verifica se a diretiva encontrada existe na tabela de instrucoes e diretivas.*/
                        else if(has_dir(operacao))
                        {

                            pc = pc + get_dir_size(operacao);
                        }
                        else {}
                        //launch_error("%d: ERRO! Operacao nao identificada na linha %s ", g_contador_de_linhas, op);
                    }
                }
                /*debug*/if(operando1 != NULL)
                /*debug*/{
                /*debug*/    printf("operand1: %s %d ", operando1, get_op_value(operando1));
                /*debug*/}
                /*debug*/if(operando2 != NULL)
                /*debug*/    printf("operand2: %s %d ", operando2, get_op_value(operando2));

                if(operacao != NULL)
                {
                    int cd=getInstructionCodByMnemonico(operacao);
                    if(cd>=0 && !flag_stop_instruction_found)
                    {
                        /*debug*/printf("Binary |%.2d| ",cd );
                        add_cl(&cl, cd);
                    }
                    else
                    {
                       if(iStringCompare(operacao, "SPACE")==0)
                       {
                          add_cl(&cl, 0);
                       }
                       else if(iStringCompare(operacao, "CONST")==0)
                       {
                          if(operando1!=NULL)
                          {
                            add_cl(&cl, (int) strtol(operando1, (char **)NULL, 10) );
                          }
                       }
                    }
                }
                if(operando1!=NULL)
                {
                    //if(iStringCompare(operacao, "STOP")==0) printf("14");
                    printf(" %.2d ", get_op_value(operando1)+1 );
                    add_cl(&cl, get_op_value(operando1)+1 );
                }
                if(operando2!=NULL)
                {
                    printf("%.2d", get_op_value(operando2)+1);
                    add_cl(&cl, get_op_value(operando2)+1 );
                }

                printf("\n");
            }
            else
            {
                printf("l:%d. Erro sintatico,",g_contador_de_linhas);
            }

        }else if(c == '\n')
            g_contador_de_linhas++;
    }

	/*fecha os arquivos ainda abertos e tchau*/
	fclose(arquivo_de_entrada_pre_processado);
	fclose(arquivo_de_saida_o);
    printf("\n\nDone!\nBye.\n");
	return 0;
}