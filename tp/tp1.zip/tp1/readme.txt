﻿Universidade de Brasília
CIC 116432 - Software Básico - Turma B - Prof. Bruno Macchiavello
1º Semestre de 2015

1º Trabalho Prático

Grupo:
EDUARDO FURTADO SÁ CORRÊA - 09/0111575
JOSÉ ANTONIO SIQUEIRA DE CERQUEIRA - 09/0043201

Ambientes de desenvolvimento:
Eduardo: OS windows 8.1 x64 com compilador gcc.exe (GCC) 4.8.1 instalado através do pacote MinGW
José: idem



ATENÇÃO:
não conseguimos implementar o ligador, apenas o montador.