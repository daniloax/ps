#include <stdio.h>
/*para usar funcoes como strcpy, strcat*/
#include <string.h>
#include <stdlib.h>

#define MAX 100

/*funções*/
int strIgual(char s1[], char s2[]);
int encontraDefine(int i);
void toLower(char s1[]);


struct struct_tabela_instrucoes_e_diretivas{
    char mnemonico[10];
    int operandos;
    int cod;
    /*tamanho em bytes*/
    int tamanho;
}Struct_tabela_instrucoes_e_diretivas;

/*variaveis globais*/
struct struct_tabela_instrucoes_e_diretivas tabela_instrucoes_e_diretivas[23];
// do ciro:
char s[MAX][MAX];


// Verifica se duas strings são iguais sem levar em consideração case sensitive
int strIgual(char s1[], char s2[]){
    toLower(s1);
    toLower(s2);
    if(strcmp(s1, s2)==0)return 1;
    else return 0;
}

void toLower(char s1[]){
    int i=0;
    while(s1[i]!=0){
        s1[i] = tolower(s1[i]);
        i++;
    }
}

int main (int argc, char *argv[])
{
	FILE * arquivo_de_entrada_asm;
	FILE * arquivo_de_entrada_pre_processado;
	FILE * arquivo_de_saida_o;
	FILE * arquivo_instrucoes_e_diretivas;

	/*nome dos arquivos de entrada e saida*/
	char nome_do_arquivo_de_entrada[200];
	char nome_do_arquivo_de_entrada_pre_processado[200];
	char nome_do_arquivo_de_saida[200];

	/*variavel auxiliar, usada para armazenar caracteres lidos de arquivos*/
	char c;

	int i;

	// variaveis do ciro
    // char token[MAX];
    // char linha[250];
    int v[MAX];
    int j = 0;
    int k = 0;
    int t_str;
    // int pos=0;

	/*verifica se os parametros de entrada são válidos*/
   	if(argc != 3){
        printf("\nPrograma requer dois parametros: ArquivoDeEntradaComExtensao.asm ArquivoDeSaidaComExtensao.o\n");
        printf("Entre apenas o nome dos arquivos, ja que se assume a extensao\n");
        exit(EXIT_FAILURE);
    }

    /*pega dos parametros de entrada do programa o nome dos arquivos de entrada e saida*/
	strcpy(nome_do_arquivo_de_entrada, argv[1]);
	strcat(nome_do_arquivo_de_entrada, ".asm");
	strcpy(nome_do_arquivo_de_entrada_pre_processado, argv[1]);
	strcat(nome_do_arquivo_de_entrada_pre_processado, "_pre_processado.asm");
	strcpy(nome_do_arquivo_de_saida, argv[2]);
	strcat(nome_do_arquivo_de_saida, ".o");

	/*abre o arquivo de entrada para leitura*/
	arquivo_de_entrada_asm = fopen(nome_do_arquivo_de_entrada, "r");
	if ( arquivo_de_entrada_asm == NULL){
		printf("\nFalha ao abrir arquivo de entrada: %s. \n",nome_do_arquivo_de_entrada);
        exit(EXIT_FAILURE);
	}

	/*abre o arquivo que tem a tabela de instrucoes e diretivas*/
	arquivo_instrucoes_e_diretivas = fopen("tabela_de_instrucoes_e_diretivas", "r");
	if ( arquivo_instrucoes_e_diretivas == NULL){
		printf("\nFalha ao abrir arquivo detabela_de_instrucoes_e_diretivas que deve estar na mesma pasta do executavel.\n");
        exit(EXIT_FAILURE);
	}

	/*uso o arquivo de instruções e diretivas para criar uma tabela em memória*/
	i = 0;
	while((c = fscanf
		(
		arquivo_instrucoes_e_diretivas,
		"%s %d %d %d",
			tabela_instrucoes_e_diretivas[i].mnemonico,
			&tabela_instrucoes_e_diretivas[i].operandos,
			&tabela_instrucoes_e_diretivas[i].cod,
			&tabela_instrucoes_e_diretivas[i].tamanho
		)
	)!= EOF)
	{
    	i++;
    }
    fclose(arquivo_instrucoes_e_diretivas);

	/*abre o arquivo de saida para escritura*/
	arquivo_de_saida_o = fopen(nome_do_arquivo_de_saida, "w+");
	if ( arquivo_de_saida_o == NULL){
		printf("\nFalha ao criar arquivo de saida: %s. \n",nome_do_arquivo_de_saida);
        exit(EXIT_FAILURE);
	}

	/*abre para escritura um arquivo para o output do pre processamento*/
	/*este arquivo de pre processamente vai ter o mesmo assembly de entrada, mas com coisas inúteis para o montador,*/
	/*como comentários, removidos*/
	arquivo_de_entrada_pre_processado = fopen(nome_do_arquivo_de_entrada_pre_processado, "w+");
	if ( arquivo_de_entrada_pre_processado == NULL){
		printf("\nFalha ao criar arquivo de saida para o output do pre processamento: %s. \n", nome_do_arquivo_de_entrada_pre_processado);
        exit(EXIT_FAILURE);
	}

	printf("\nHello SB!\n");

    //Inicia o pré processamento identificando os Equals
	i = 1;
	/*Isso é do ciro. Se ve que no trabalho dele tinha os mnem^onicos EQU e IFS, enquanto no nosso temos EXTERN e PUBLIC de extras.
	deixo o código aqui comentado para DELETAR no final, porque tenho o pressentimento de que talvez venh a ser útil pro nosso caso.*/
    do
    {
        fscanf(arquivo_de_entrada_asm, "%s", s[0]);
        printf("s[0]: %s\n",&s[0]);
        t_str = strlen(s[0]);
        if(s[0][t_str-1]==':'){
            fscanf(arquivo_de_entrada_asm, "%s", s[MAX-1]);;
            printf("s[MAX-1][0]: %s\n",&s[MAX-1]);
            if(s[MAX-1][0]=='E'){
            	printf("E \n");
                fscanf(arquivo_de_entrada_asm, "%d", &v[i]);
                strcpy(s[i], s[0]);
                s[i][t_str-1] = 00;
                i++;
            }
        }
    } while((c = fgetc(arquivo_de_entrada_asm))!= EOF);
	rewind(arquivo_de_entrada_asm);


    /*PREPROCESSAMENTO*/
    while(((c = fgetc(arquivo_de_entrada_asm))!= EOF)){
    	/*verifica se é um comentário*/
        if(c==';')
        {
        	/*se é um comentário, leio até o fim da linha, com intenção de descartar os chars lidos e escrever apenas o salto de linha*/
            do{
                c = fgetc(arquivo_de_entrada_asm);
            }while((c != '\n'));
            fputc(c, arquivo_de_entrada_pre_processado);
        }
        /*se não é comentário*/
        else
        {
printf("1 \n");
            j=0;
            s[i][j] = c;

            while( ((c = fgetc(arquivo_de_entrada_asm)) != ' ') && (c != '\n') && (c != EOF) )
            {
printf("2 \n");
                j++;
                s[i][j] = c;
            }
            s[i][j+1] = 00;
            if(strIgual(tabela_instrucoes_e_diretivas[18].mnemonico, s[i])==1){
printf("3 \n");
                j=0;
                s[i][j] = fgetc(arquivo_de_entrada_asm);
                while( ((c = fgetc(arquivo_de_entrada_asm)) != ' ') && (c != '\n') && (c != EOF) ){
printf("4 \n");
                    j++;
                    s[i][j] = c;
                }
                s[i][j+1] = 00;
                if(s[i][0]=='0'){
printf("5 \n");
                        while( (c = fgetc(arquivo_de_entrada_asm)!= '\n') && (c != EOF) );
                        fputc('\n', arquivo_de_entrada_pre_processado);fputc('\n', arquivo_de_entrada_pre_processado);
                }else{
printf("8 \n");
                    fprintf(arquivo_de_entrada_pre_processado, "IF   %s", s[i]);
                }

            }else{
            	fprintf(arquivo_de_entrada_pre_processado, "%s", s[i]);
printf("10 \n");
			}
            if(c==' '){
                fputc(c, arquivo_de_entrada_pre_processado);
printf("11 \n");
            }
            else if (c=='\n'){
printf("12 \n");
                fputc(c,arquivo_de_entrada_pre_processado);
            }
        }
    }

    for (i = 0; i < 1000; i++)
    {
    	printf("-%c-",&s[i]);
    }

	/*fecha os arquivos abertos e limpa o buffer de arquivo_de_entrada_asm*/
	fclose(arquivo_de_entrada_asm);
	// free(buffer);
	fclose(arquivo_de_saida_o);
	return 0;
}